const users = {
  "julierbo151102": { password: "123456", balance: 10000 },
  "naingaung151102": { password: "151102", balance: 0 },
};

let currentUser = null;

function login() {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;

  if (users[user] && users[user].password === pass) {
    currentUser = user;
    document.getElementById("orderForm").style.display = "block";
    document.getElementById("welcomeUser").textContent = "Hello, " + user;
    document.getElementById("balance").textContent = users[user].balance;
  } else {
    alert("Invalid credentials");
  }
}

function updateDiamondOptions() {
  const type = document.getElementById("diamondType").value;
  const select = document.getElementById("diamondOption");
  select.innerHTML = "";

  const options = {
    weekly: ["wkp - 6500", "wkp2 - 13000", "wkp3 - 19500"],
    diamond: [
      "💎11 - 950", "💎22 - 1900", "💎33 - 2850", "💎56 - 4200",
      "💎112 - 8200", "💎86 - 5100", "💎172 - 10200", "💎257 - 15300",
      "💎343 - 20400", "💎429 - 25500", "💎514 - 30600", "💎600 - 35700",
      "💎706 - 40800", "💎878 - 51000", "💎963 - 56100", "💎1049 - 61200",
      "💎1135 - 66300", "💎1412 - 81600", "💎2195 - 122400", "💎3688 - 204000",
      "💎5532 - 306000", "💎9288 - 510000", "💎12976 - 714000"
    ],
    "2x": ["💎55+ - 3500", "💎165+ - 10000", "💎275+ - 16000", "💎565+ - 33000"],
  };

  options[type]?.forEach(opt => {
    const o = document.createElement("option");
    o.textContent = opt;
    select.appendChild(o);
  });
}

function updatePrice() {
  const selected = document.getElementById("diamondOption").value;
  document.getElementById("priceDisplay").textContent = "Price: " + selected.split("-")[1]?.trim() + " Ks";
}

function submitOrder() {
  alert("Order submitted!");
}

function adminLogin() {
  const user = document.getElementById("adminUser").value;
  const pass = document.getElementById("adminPass").value;
  if (user === "naingaung151102" && pass === "151102") {
    document.getElementById("adminPanel").style.display = "block";
  } else {
    alert("Invalid admin credentials");
  }
}

function topupBalance() {
  const user = document.getElementById("topupUser").value;
  const amount = parseInt(document.getElementById("topupAmount").value);
  if (users[user]) {
    users[user].balance += amount;
    alert("Balance updated for " + user + ": " + users[user].balance + " Ks");
  } else {
    alert("User not found");
  }
}